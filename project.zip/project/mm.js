const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

// Create an Express app
const app = express();

// Set up MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/room_reservations', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define schema for reservations
const reservationSchema = new mongoose.Schema({
  name: String,
  email: String,
  date: String,
  time: String,
  guests: Number,
  specialRequests: String,
});

// Create the Reservation model
const Reservation = mongoose.model('Reservation', reservationSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serve the reservation form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'reserve.html'));
});

// Handle form submission
app.post('/reserve', async (req, res) => {
  const reservationData = new Reservation(req.body);
  try {
    await reservationData.save();
    res.send('Reservation saved successfully!');
  } catch (err) {
    res.status(500).send('Error saving reservation.');
  }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
