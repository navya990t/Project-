<script>
    // Sample data: Destinations with travel times in hours
    const destinations = [
        { name: "Rajiv Gandhi International Airport", location: "Hyderabad", travelTime: 1 },
        { name: "Chatrapathi Sivaji International Airport", location: "Mumbai", travelTime: 2 },
        { name: "Indira Gandhi International Airport", location: "Delhi", travelTime: 3 },
    ];

    // Function to calculate possible destinations
    function calculateDestinations() {
        // Get input values for transit hour and departure time
        const transitHourInput = document.querySelector("input[placeholder='⏰ Transit hour']").value;
        const departureTimeInput = document.getElementById("departure-time").value;

        // Validate inputs
        if (!transitHourInput || !departureTimeInput) {
            alert("Please enter both transit hours and departure time.");
            return;
        }

        const transitHours = parseFloat(transitHourInput);
        // We don't need to use departureTimeInput for calculations, but it's still collected
        const departureTime = new Date(`1970-01-01T${departureTimeInput}:00`);

        // Calculate reachable destinations based on transit hour
        const reachableDestinations = destinations.filter(destination => destination.travelTime <= transitHours);

        // Get the results container to display the output
        const resultsContainer = document.querySelector(".search-section p");

        // Display the results
        if (reachableDestinations.length > 0) {
            resultsContainer.innerHTML = `You can travel to: <br>${reachableDestinations
                .map(dest => `<b>${dest.name}</b> in ${dest.location} (Travel Time: ${dest.travelTime} hours)`)
                .join("<br>")}`;
        } else {
            resultsContainer.innerHTML = "No destinations available within the given transit hours.";
        }
    }

    // Attach event listener to the Calculate button
    document.querySelector(".btn-primary").addEventListener("click", calculateDestinations);
</script>
