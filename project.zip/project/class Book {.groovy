class Book {
private:
    string title;
    string author;
    int yearPublished;

public:
    // Constructor
    Book(string t, string a, int y) : title(t), author(a), yearPublished(y) {}

    // Getter and Setter methods
    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    int getYearPublished() const { return yearPublished; }

    void setTitle(string t) { title = t; }
    void setAuthor(string a) { author = a; }
    void setYearPublished(int y) { yearPublished = y; }

    // Method to display book details
    void displayInfo() const {
        cout << "Title: " << title << ", Author: " << author << ", Year: " << yearPublished << endl;
    }
};

class Library {
private:
    vector<Book> books;

public:
    // Add a book to the library
    void addBook(const Book& b) {
        books.push_back(b);
    }

    // Display all books in the library
    void displayBooks() const {
        for (const auto& book : books) {
            book.displayInfo();
        }
    }
};
