<?php
// Database connection
$host = 'localhost';  // The host (localhost if using XAMPP)
$username = 'root';   // Default username for MySQL in XAMPP
$password = '';       // Default password for MySQL in XAMPP (empty)
$dbname = 'reserve';  // Correct database name

// Create a connection to MySQL
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $guests = $_POST['guests'];
    $special_requests = $_POST['special-requests'];
    $card_name = $_POST['card-name'];
    $card_number = $_POST['card-number'];
    $expiration_date = $_POST['expiration-date'];
    $cvv = $_POST['cvv'];

    // Prepare the SQL query to insert data into the database
    $sql = "INSERT INTO reservations (name, email, date, time, guests, special_requests, card_name, card_number, expiration_date, cvv)
            VALUES ('$name', '$email', '$date', '$time', '$guests', '$special_requests', '$card_name', '$card_number', '$expiration_date', '$cvv')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "Reservation successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
